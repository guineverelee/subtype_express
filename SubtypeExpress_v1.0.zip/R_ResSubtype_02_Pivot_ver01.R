#Objective:  Nonoverlapping window subtyping tool for reservoir sequeces.  Supports truncated sequences.
#About 1 minute per row
#Files:  Query.fasta, R script, HXB2_REF_Genes_ver01.fasta, LosAlamos_Subtype_Con...fasta

#Step 00. Setup R #PC@work R version 3.2.2
rm(list=ls())
closeAllConnections() 
graphics.off() 
cat("\014") #send CTRL+L to R, clean console
StartSysTime <- Sys.time()
MyWD <- getwd()
setwd(MyWD)
#library(Biostrings) #PC@work Biostrings_2.38.1
#library(muscle) #PC@work muscle_3.12.0
MyBlastnDir <- "/Users/guin/"
#sessionInfo()

unlink("./Output_02_Subtype_Pivot/",recursive=TRUE)
dir.create("./Output_02_Subtype_Pivot/")

MyInputPIDTables_FileNames <- list.files("Output_01_Subtype_PID")
MyInputPIDTables_FileNames_link <- paste("./Output_01_Subtype_PID/",MyInputPIDTables_FileNames,sep="")

for (i in 1:length(MyInputPIDTables_FileNames)){
  #i=2
  ########################
  MyOutput_01_SeqID <- c()
  MyOutput_02_SubtypeFull <- c()
  MyOutput_03_SubtypeShort <- c()
  ########################
  MyCurrentDF <- read.csv(MyInputPIDTables_FileNames_link[i])
  MyUniqueSeqID <- as.character(unique(MyCurrentDF$seqid))
  for (j in 1:length(MyUniqueSeqID)){
    #j=1
    MyCurrentDF_UniqueSeqID <- subset(MyCurrentDF,MyCurrentDF$seqid==MyUniqueSeqID[j])
    MyCurrent_Subtype <- gsub("CONSENSUS_","",MyCurrentDF_UniqueSeqID$MyPID_Max_REF)
    MyCurrent_Subtype_Collapsed_Full <- paste(MyCurrent_Subtype,collapse = ",")
    MyCurrent_Subtype_RemoveNA <- MyCurrent_Subtype[!is.na(MyCurrent_Subtype)]
    MyCurrent_Subtype_Collapsed_Short <- paste(names(table(MyCurrent_Subtype_RemoveNA)),collapse = ",")
    if (length(MyCurrent_Subtype_RemoveNA)==0){
      MyCurrent_Subtype_Collapsed_Short <- NA
    } else {
      #do nothing
    }
    ### Paste into table
    MyOutput_01_SeqID <- append(MyOutput_01_SeqID,MyUniqueSeqID[j])
    MyOutput_02_SubtypeFull <- append(MyOutput_02_SubtypeFull,MyCurrent_Subtype_Collapsed_Full)
    MyOutput_03_SubtypeShort <- append(MyOutput_03_SubtypeShort,MyCurrent_Subtype_Collapsed_Short)
  }
  MyFinalDF <- as.data.frame(cbind(
    MyOutput_01_SeqID
    ,MyOutput_02_SubtypeFull
    ,MyOutput_03_SubtypeShort
  ))
  MyOutputFileName_Current <- paste("./Output_02_Subtype_Pivot/",gsub(".csv","",MyInputPIDTables_FileNames[i]),"_Pivot.csv",sep="")
  write.csv(MyFinalDF,file=MyOutputFileName_Current)
}


#Step 03. End
EndSysTime <- Sys.time()
print(paste("Script started running",StartSysTime))
print(paste("Script finished running",EndSysTime))

