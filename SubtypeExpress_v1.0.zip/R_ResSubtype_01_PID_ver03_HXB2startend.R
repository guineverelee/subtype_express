#Objective:  Nonoverlapping window subtyping tool for reservoir sequeces.  Supports truncated sequences.
#About 1 minute per row
#Files:  Query.fasta, R script, HXB2_REF_Genes_ver01.fasta, LosAlamos_Subtype_Con...fasta
#20211014 Update script to HXB2start=1 HXB2end=genelength to ensure entire gene was present
#this script is forcing 70%PID cutoff, HXB2start=1 HXB2end=width... that means, if the query is less than 70%PID, it will not be exported. 

#Step 00. Setup R #PC@work R version 3.2.2
rm(list=ls())
closeAllConnections() 
graphics.off() 
cat("\014") #send CTRL+L to R, clean console
StartSysTime <- Sys.time()
MyWD <- getwd()
setwd(MyWD)
library(Biostrings) #PC@work Biostrings_2.38.1
#library(muscle) #PC@work muscle_3.12.0
MyBlastnDir <- "/Users/guin/"
#sessionInfo()

unlink("./Output_01_Subtype_PID/",recursive=TRUE)
dir.create("./Output_01_Subtype_PID/")

#Step 01. User Settings
MyInput_Query_FileName <- "Test_Input_8E5_S1049.fasta"  #"AndyNonB_n398.fasta"
MyInput_REF_FileName <- "LoMo_2021_SubtypeCon_NoRecomb_ver02.fasta"
MyInput_HXB2_Genes_FileName <- "HXB2_REF_Genes_ver01.fasta"
MyWindowNonOverlap_Size <- 499 #99 means windowsize of 100, 999 means windowsize of 1000
MyOutput_Subtype_FileName_01_ByWinSize <- paste("./Output_01_Subtype_PID/Output_01_ResSubtyping_REFNoRecomb_WinSize",as.character(MyWindowNonOverlap_Size+1),".csv",sep="")
MyOutput_Subtype_FileName_02_ByGene <- "./Output_01_Subtype_PID/Output_02_ResSubtyping_REFNoRecomb_ByGene.csv"
#"PID1":
#100 * (identical positions) / (aligned positions + internal gap positions)

#Step 02. Read fasta as DNAStringSet
MyInput_Query <- readDNAStringSet(MyInput_Query_FileName)
MyInput_REF <- readDNAStringSet(MyInput_REF_FileName)
MyInput_HXB2_Genes <- readDNAStringSet(MyInput_HXB2_Genes_FileName)

# #Step 03. Blastn query
#Removed

#Step 04. Split query by window, create coordinate vector *non-overlap*
MyWindowNonOverlap_Name <- c()
MyWindowNonOverlap_Start <- c()
MyWindowNonOverlap_End <- c()
for (i in 1:length(MyInput_Query)){
  #calculate the number of fragments
  MyFragCount <- floor(width(MyInput_Query[i])/(MyWindowNonOverlap_Size+1))
  MyStart <- 1
  #WindowSize is larger than query length
  if (MyFragCount==0) {
    MyWindowNonOverlap_Name <- append(MyWindowNonOverlap_Name,names(MyInput_Query[i]))
    MyWindowNonOverlap_Start <- append(MyWindowNonOverlap_Start,MyStart)
    MyWindowNonOverlap_End <- append(MyWindowNonOverlap_End,width(MyInput_Query[i]))
  } else {
    for (j in 1:MyFragCount){
      if (j<MyFragCount){
        MyWindowNonOverlap_Name <- append(MyWindowNonOverlap_Name,names(MyInput_Query[i]))
        MyWindowNonOverlap_Start <- append(MyWindowNonOverlap_Start,MyStart)
        MyWindowNonOverlap_End <- append(MyWindowNonOverlap_End,(MyStart+MyWindowNonOverlap_Size))
        MyStart <- MyStart + MyWindowNonOverlap_Size + 1
      } else if (j==MyFragCount) {
        MyWindowNonOverlap_Name <- append(MyWindowNonOverlap_Name,names(MyInput_Query[i]))
        MyWindowNonOverlap_Start <- append(MyWindowNonOverlap_Start,MyStart)
        MyWindowNonOverlap_End <- append(MyWindowNonOverlap_End,width(MyInput_Query[i]))
      } else {
        #do nothing
      }
    }
  }
}
MyFinalCoordinate_DB <- c() #reset
MyFinalCoordinate_DB <- as.data.frame(cbind(
  MyWindowNonOverlap_Name
  ,MyWindowNonOverlap_Start
  ,MyWindowNonOverlap_End
))
colnames(MyFinalCoordinate_DB) <- c("seqid","qstart","qend")
#View(MyFinalCoordinate_DB)


#Step 05. PID function
MyPIDFunction <- function(output="Output_Default.csv"){
  MyAlignedLength_Collapse <-c()
  MyPID_Collapse <- c()
  MyPID_Max_REF <- c()
  MyPID_Max_Value <- c()
  MyPID_Note <- c()
  MyPID_AlignLen <- c()
  for (i in 1:nrow(MyFinalCoordinate_DB)){
    #i=10
    if (is.na(as.numeric(MyFinalCoordinate_DB$qstart[i]))){
      MyAlignedLength_Collapse <- append(MyAlignedLength_Collapse,NA)
      MyPID_Collapse <- append(MyPID_Collapse,NA)
      MyPID_Max_REF <- append(MyPID_Max_REF,NA)
      MyPID_Max_Value <- append(MyPID_Max_Value,NA)
      MyPID_Note <- append(MyPID_Note,NA)
      MyPID_AlignLen <- append(MyPID_AlignLen,NA)
    } else {
      #Subseq per row in windowsize df
      MyCurrentSEQ <- subseq(MyInput_Query[MyFinalCoordinate_DB$seqid[i]]
                             ,start=as.numeric(as.character(MyFinalCoordinate_DB$qstart[i]))
                             ,end=as.numeric(as.character(MyFinalCoordinate_DB$qend[i]))
      )
      #Pairwisealign to each REF
      MyCurrentPID <- c()
      MyCurrentREF <- c()
      MyCurrentAlignedLength <- c()
      for (j in 1:length(MyInput_REF)){
        MyCurrentAlign <- pairwiseAlignment(MyCurrentSEQ
                                            ,MyInput_REF[j]
                                            ,type="global-local"
                                            ,gapOpening=10
                                            ,gapExtension=4)
        #writePairwiseAlignments(MyCurrentAlign,file="Test02_global-local_B2.txt")
        MyCurrentREF <- append(MyCurrentREF,names(MyInput_REF[j]))
        MyCurrentPID <- append(MyCurrentPID,pid(MyCurrentAlign,type="PID1"))
        MyAlignedLength <- nchar(gsub("-","",pattern(MyCurrentAlign)))
        MyCurrentAlignedLength <- append(MyCurrentAlignedLength,MyAlignedLength)
      }
      MyAlignedLength_Collapse <- append(MyAlignedLength_Collapse,paste(as.character(MyCurrentAlignedLength),collapse = ";"))
      MyPID_Collapse <- append(MyPID_Collapse,paste(as.character(signif(MyCurrentPID,digits=3)),collapse = ";"))
      print(paste("Row ",as.character(i)," of ",as.character(nrow(MyFinalCoordinate_DB))," has this many max PID names: ", length(names(MyInput_REF[which(MyCurrentPID==max(MyCurrentPID))])),sep=""))
      #Need to fix bug:  if same PID #HERE# fixed
      if (length(which(MyCurrentPID==max(MyCurrentPID)))==1){
        MyPID_Max_REF <- append(MyPID_Max_REF,names(MyInput_REF[which(MyCurrentPID==max(MyCurrentPID))]))
        MyPID_Max_Value <- append(MyPID_Max_Value,max(MyCurrentPID))
        MyPID_AlignLen <- append(MyPID_AlignLen,MyCurrentAlignedLength[which(MyCurrentPID==max(MyCurrentPID))])
        MyPID_Note <- append(MyPID_Note,"Single Max")
      } else if (length(which(MyCurrentPID==max(MyCurrentPID)))>1){  #if same PID, take the first one (for now)
        MyPID_Max_REF <- append(MyPID_Max_REF,paste(names(MyInput_REF[which(MyCurrentPID==max(MyCurrentPID))]),collapse = ";"))
        MyPID_Max_Value <- append(MyPID_Max_Value,paste(MyCurrentPID[which(MyCurrentPID==max(MyCurrentPID))],collapse = ";"))
        MyPID_AlignLen <- append(MyPID_AlignLen,paste(MyCurrentAlignedLength[which(MyCurrentPID==max(MyCurrentPID))],collapse = ";"))
        MyPID_Note <- append(MyPID_Note,"Multiple Max")
      } else {
        MyPID_Max_REF <- append(MyPID_Max_REF,"ND")
        MyPID_Max_Value <- append(MyPID_Max_Value,"ND")
        MyPID_AlignLen <- append(MyPID_AlignLen,"ND")
        MyPID_Note <- append(MyPID_Note,"PID<1")
      }
    }
  }
  MyFinalCoordinate_DB <- as.data.frame(cbind(
    MyFinalCoordinate_DB
    ,MyAlignedLength_Collapse
    ,MyPID_Collapse
    ,MyPID_Max_REF
    ,MyPID_Max_Value
    ,MyPID_AlignLen
    ,MyPID_Note
  ))
  #View(MyFinalCoordinate_DB)
  write.csv(MyFinalCoordinate_DB,file=output)
}

#Step06.  Call PID function for WindowSize nonoverlap
MyPIDFunction(output=MyOutput_Subtype_FileName_01_ByWinSize)


#Step07.  Split by gene coordinate table
MyByGene_SeqID <- c()
MyByGene_GeneName <- c()
MyByGene_HXB2Start <- c()
MyByGene_HXB2End <- c()
MyByGene_Start <- c()
MyByGene_End <- c()
MyByGene_MapPID <- c()
for (i in 1:length(MyInput_Query)){
  #i=2
  for (j in 1:length(MyInput_HXB2_Genes)){
    #j=5
    #Step1. Try to find the gene in the query
    MyCurrentAlign <- pairwiseAlignment(MyInput_HXB2_Genes[j]
                                        ,MyInput_Query[i]
                                        ,type="global-local")
    MyInput_HXB2_Gene_OrigWidth <- width(MyInput_HXB2_Genes[j])
    MyHXB2_Start <- start(pattern(MyCurrentAlign))
    MyHXB2_End <- end(pattern(MyCurrentAlign))
    MyQuery_Start <- start(subject(MyCurrentAlign))
    MyQuery_End <- end(subject(MyCurrentAlign))
    MyPID <- round(pid(MyCurrentAlign),digits=1)
    #Step2. Write to table
    MyByGene_SeqID <- append(MyByGene_SeqID,names(MyInput_Query[i]))
    if (MyPID>=70 & MyHXB2_Start==1 & MyHXB2_End==MyInput_HXB2_Gene_OrigWidth){
      MyByGene_GeneName <- append(MyByGene_GeneName,names(MyInput_HXB2_Genes[j]))
      MyByGene_Start <- append(MyByGene_Start,MyQuery_Start)
      MyByGene_End <- append(MyByGene_End,MyQuery_End)
      MyByGene_MapPID <- append(MyByGene_MapPID,MyPID)
      MyByGene_HXB2Start <- append(MyByGene_HXB2Start,MyHXB2_Start)
      MyByGene_HXB2End <- append(MyByGene_HXB2End,MyHXB2_End)
    # } else if (MyPID<70 & MyPID>=60 & MyHXB2_Start==1 & MyHXB2_End==MyInput_HXB2_Gene_OrigWidth) {
    #   MyByGene_GeneName <- append(MyByGene_GeneName,paste(names(MyInput_HXB2_Genes[j]),"_PID60to70",sep=""))
    #   MyByGene_Start <- append(MyByGene_Start,MyQuery_Start)
    #   MyByGene_End <- append(MyByGene_End,MyQuery_End)
    #   MyByGene_MapPID <- append(MyByGene_MapPID,MyPID)
    #   MyByGene_HXB2Start <- append(MyByGene_HXB2Start,MyHXB2_Start)
    #   MyByGene_HXB2End <- append(MyByGene_HXB2End,MyHXB2_End)
    } else {
      MyByGene_GeneName <- append(MyByGene_GeneName,paste(names(MyInput_HXB2_Genes[j]),"_partial",sep=""))
      MyByGene_Start <- append(MyByGene_Start,NA)
      MyByGene_End <- append(MyByGene_End,NA)
      MyByGene_MapPID <- append(MyByGene_MapPID,"Missing;PID<70")
      MyByGene_HXB2Start <- append(MyByGene_HXB2Start,MyHXB2_Start)
      MyByGene_HXB2End <- append(MyByGene_HXB2End,MyHXB2_End)
    }
  }
}
MyFinalCoordinate_DB <- c() #reset
MyFinalCoordinate_DB <- as.data.frame(cbind(
   MyByGene_SeqID
  ,MyByGene_GeneName
  ,MyByGene_HXB2Start
  ,MyByGene_HXB2End
  ,MyByGene_Start
  ,MyByGene_End
  ,MyByGene_MapPID
))
colnames(MyFinalCoordinate_DB) <- c("seqid","gene","sstart","send","qstart","qend","mapPID")

#Step06.  Call PID function for WindowSize nonoverlap
MyPIDFunction(output=MyOutput_Subtype_FileName_02_ByGene)


#Step 03. End
EndSysTime <- Sys.time()
print(paste("Script started running",StartSysTime))
print(paste("Script finished running",EndSysTime))

